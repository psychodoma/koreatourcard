<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='이벤트';
$list=array (
)?>